// "+ Add new client…" for client pickers: <select data-quick-client>. Adds a row to the list and opens a small popup;
// the new client is saved through /admin/orders/quick-client, added to the list and selected. A link with
// data-add-client opens the same popup for the client select in the same form.
(function () {
  const sels = [...document.querySelectorAll('select[data-quick-client]')];
  if (!sels.length) return;
  const NEW = '__newclient';
  let dlg, cur, prev = new Map();
  sels.forEach(s => {
    if (![...s.options].some(o => o.value === NEW)) s.appendChild(new Option('+ Add new client…', NEW));
    prev.set(s, s.value);
    s.addEventListener('change', () => { if (s.value === NEW) { s.value = prev.get(s) || ''; open(s); } else prev.set(s, s.value); });
  });
  function build() {
    dlg = document.createElement('dialog'); dlg.className = 'modaldlg qcdlg';
    dlg.innerHTML = '<form method="dialog" class="modalform" novalidate><h2>New client</h2>'
      + '<p class="muted small">Just the basics — complete the rest on the client page, where you can also invite their users.</p>'
      + '<div class="fld"><label>Company name <span class="req">*</span></label><input data-f="name" maxlength="200" autocomplete="off"></div>'
      + '<div class="qc2"><div class="fld"><label>Country</label><input data-f="country" maxlength="100"></div><div class="fld"><label>City</label><input data-f="city" maxlength="100"></div></div>'
      + '<div class="qc2"><div class="fld"><label>Email</label><input data-f="email" type="email" maxlength="200"></div><div class="fld"><label>Phone</label><input data-f="phone" maxlength="60"></div></div>'
      + '<div class="fld"><label>Default currency</label><select data-f="default_currency"><option>USD</option><option>EUR</option><option>GBP</option><option>CNY</option></select></div>'
      + '<div class="ferr qcerr" hidden></div>'
      + '<div class="actions"><button type="button" class="btn" data-x>Cancel</button><button type="submit" class="btn primary" data-ok>Add client</button></div></form>';
    document.body.appendChild(dlg);
    const f = k => dlg.querySelector('[data-f=' + k + ']'), err = t => { const e = dlg.querySelector('.qcerr'); e.hidden = !t; e.textContent = t || ''; };
    dlg.querySelector('[data-x]').addEventListener('click', () => dlg.close());
    dlg.addEventListener('click', e => { if (e.target === dlg) dlg.close(); });
    dlg.querySelector('form').addEventListener('submit', async e => {
      e.preventDefault();
      const name = f('name').value.trim(); if (!name) { err('Enter the client name.'); f('name').focus(); return; }
      const ok = dlg.querySelector('[data-ok]'); ok.disabled = true; err('');
      try {
        const body = {}; dlg.querySelectorAll('[data-f]').forEach(x => { body[x.dataset.f] = x.value.trim(); });
        const res = await fetch('/admin/orders/quick-client', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body) });
        const j = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(j.error || 'Could not add the client.');
        sels.forEach(s => { if (![...s.options].some(o => o.value === j.id)) s.insertBefore(new Option(j.name, j.id), s.querySelector('option[value=' + NEW + ']')); });
        cur.value = j.id; prev.set(cur, j.id); cur.dispatchEvent(new Event('change', { bubbles: true }));
        dlg.close();
      } catch (x) { err(x.message); } finally { ok.disabled = false; }
    });
    dlg.addEventListener('close', () => { dlg.querySelectorAll('[data-f]').forEach(x => { if (x.tagName === 'INPUT') x.value = ''; }); err(''); });
  }
  function open(sel) {
    if (!dlg) build();
    cur = sel; setTimeout(() => { dlg.showModal(); dlg.querySelector("[data-f=name]").focus(); }, 0);
  }
  document.addEventListener('click', e => {
    const a = e.target.closest('[data-add-client]'); if (!a) return;
    e.preventDefault();
    const s = (a.closest('form') || document).querySelector('select[data-quick-client]'); if (s) open(s);
  });
})();
